opTable = {
    "FIX": {"op": "C4", "format": 1},
    "FLOAT": {"op": "C0", "format": 1},
    "HIO": {"op": "F4", "format": 1},
    "NORM": {"op": "C8", "format": 1},
    "SIO": {"op": "F0", "format": 1},
    "TIO": {"op": "F8", "format": 1},
    "ADDR": {"op": "90", "format": 2},
    "COMPR": {"op": "A0", "format": 2},
    "DIVR": {"op": "9C", "format": 2},
    "CLEAR": {"op": "B4", "format": 2},
    "SHIFTL": {"op": "A4", "format": 2},
    "MULR": {"op": "98", "format": 2},
    "RMO": {"op": "AC", "format": 2},
    "SHIFTR": {"op": "A8", "format": 2},
    "SUBR": {"op": "94", "format": 2},
    "SVC": {"op": "B0", "format": 2},
    "TIXR": {"op": "B8", "format": 2},
    "RSUB": {"op": "4C", "format": 3},
    "LDA": {"op": "00", "format": 3},
    "STA": {"op": "0C", "format": 3},
    "LDB": {"op": "68", "format": 3},
    "ADD": {"op": "18", "format": 3},
    "ADDF": {"op": "58", "format": 3},
    "AND": {"op": "40", "format": 3},
    "COMP": {"op": "28", "format": 3},
    "COMPF": {"op": "88", "format": 3},
    "DIV": {"op": "24", "format": 3},
    "DIVF": {"op": "64", "format": 3},
    "J": {"op": "3C", "format": 3},
    "JEQ": {"op": "30", "format": 3},
    "JGT": {"op": "34", "format": 3},
    "JLT": {"op": "38", "format": 3},
    "JSUB": {"op": "48", "format": 3},
    "LDDCH": {"op": "50", "format": 3},
    "LDF": {"op": "70", "format": 3},
    "LDL": {"op": "08", "format": 3},
    "LDS": {"op": "6C", "format": 3},
    "LDT": {"op": "74", "format": 3},
    "LDX": {"op": "04", "format": 3},
    "LPS": {"op": "D0", "format": 3},
    "MUL": {"op": "20", "format": 3},
    "MULF": {"op": "60", "format": 3},
    "OR": {"op": "44", "format": 3},
    "RD": {"op": "D8", "format": 3},
    "SSK": {"op": "EC", "format": 3},
    "STB": {"op": "78", "format": 3},
    "STCH": {"op": "54", "format": 3},
    "STF": {"op": "80", "format": 3},
    "STI": {"op": "D4", "format": 3},
    "STL": {"op": "14", "format": 3},
    "STS": {"op": "7C", "format": 3},
    "STSW": {"op": "E8", "format": 3},
    "STT": {"op": "84", "format": 3},
    "STX": {"op": "10", "format": 3},
    "SUB": {"op": "1C", "format": 3},
    "SUBF": {"op": "5C", "format": 3},
    "TD": {"op": "E0", "format": 3},
    "TIX": {"op": "2C", "format": 3},
    "WD": {"op": "DC", "format": 3},
    "CADD": {"op": "BC", "format": 4},
    "CSUB": {"op": "8C", "format": 4},
    "CLOAD": {"op": "E4", "format": 4},
    "CSTORE": {"op": "FC", "format": 4},
    "CJUMP": {"op": "CC", "format": 4},
    
}
directives = ['START','END','BYTE','RESB','WORD','RESW','BASE','USE','LTORG','EQU','*']

blocks = {
    "DEFAULT": {"start":0,"size":0},
    "DEFAULTB": {"start":0,"size":0},
    "CDATA": {"start":0,"size":0},
    "CBLKS": {"start":0,"size":0}
}

current_block = "DEFAULT"
def hexify(x):
    return f"{x:04X}"
def location_counter_managment(location_counter, opcode, operand,line):
    global current_block
    if opcode.startswith("+"):
        location_counter += 4
    elif opcode in opTable:  
        location_counter += opTable[opcode]["format"]
    elif opcode == "RESW": 
        location_counter += 3 * int(operand)
    elif opcode == "RESB":
        location_counter += int(operand)
    elif opcode == "BYTE":
        if operand.startswith("C'"):
            location_counter += len(operand) - 3  # Subtract 3 to account for C' and '
        elif operand.startswith("X'") and operand.endswith("'"):
            location_counter += (len(operand) - 3) // 2  # Each pair of hex digits represents one byte
    elif opcode == "WORD":
        location_counter += 3
    elif opcode == "USE":
        if operand not in blocks and operand != "":
            print(f"Unrecognized block name. in line : {line}")
        elif operand != "":
            if current_block == "DEFAULT":
                blocks["DEFAULT"]["start"] = location_counter
            blocks[current_block]["start"] = location_counter
            blocks[current_block]["size"] = hexify(location_counter)
            current_block = operand
            location_counter = blocks[operand]["start"]
            print(blocks)
        elif operand is "":
            blocks[current_block]["size"] = hexify(location_counter)
            blocks[current_block]["start"] = location_counter
            current_block = "DEFAULT"
            location_counter = blocks["DEFAULT"]["start"]
    elif opcode =="END":
        blocks[current_block]["size"] = hexify(location_counter)
        blocks[current_block]["start"] = location_counter
    return location_counter,current_block
    

def column_breakdown(columns):
    if columns[0] in opTable or columns[0] in directives or (columns[0].startswith('+') and columns[0][1:] in opTable):
        label = ""
        opcode = columns[0]
        operand = " ".join(columns[1:]) if len(columns) > 1 else ""
        return label, opcode, operand  # Add return statement here
    else:
            label = columns[0]
            opcode = columns[1]
            operand = " ".join(columns[2:]) if len(columns) > 2 else ""
            return label, opcode, operand  # Ensure return is present here too

def literal_array_empty(literals,formatted_lines,location_counter,label,opcode,operand):
        # Define column widths
        loc_width = 6   # Width for location counter
        label_width = len(label) 
        opcode_width = len(opcode) 
        operand_width = len(operand) 

        if opcode == "LTORG" or (literals and opcode == "END"):
                seen_literals = set()
                for literal in literals:
                    if literal not in seen_literals:
                        formatted_lines.append(f"{hexify(location_counter):<{loc_width}}  *{' ' * (label_width)} {literal:<{operand_width}}")
                    seen_literals.add(literal)
                    if literal.startswith("=C"):
                        location_counter += len(literal) - 4
                    elif literal.startswith("=X"):
                        location_counter += (len(literal) - 3) // 2
                literals.clear()
        return location_counter  
def read_block_addresses(filename):
    block_addresses = {}
    try:
        with open(filename, "r") as file:
            for index, line in enumerate(file):
                if index == 0:
                    continue  # Skip the first line
                line = line.strip()
                if line:
                    parts = line.split()
                    if len(parts) >= 2:
                        block_name = parts[0]
                        block_address = parts[1]
                        block_addresses[block_name] = int(block_address, 16)
                        print(block_addresses)
                    else:
                        print(f"Warning: Invalid line in block_table.txt: {line}")
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    return block_addresses


def symbol_literal_table(location_counter, current_line, current_block, seen_literals):
    block_addresses = read_block_addresses("block_table.txt")
    print(block_addresses)
    try:
        with open("labels.txt", "a") as labels_output, open("literals.txt", "a") as literals_output:
            columns = current_line.strip().split(maxsplit=3)

            if len(columns) > 0:
                # Check if the first column can be converted to an integer (hexadecimal)
                try:
                    location_counter = int(columns[0], 16)
                except ValueError:
                    # Skip this line if the first column is not a valid hex number
                    pass

            if len(columns) > 1 and columns[1]:
                label = columns[1]
                if (label not in opTable and label not in directives
                    and not label.startswith("+") and not label.startswith("=")):
                    label_address = block_addresses[current_block] + location_counter
                    labels_output.write(f"{label:<10}  {label_address:04X}\n")

            if len(columns) > 2 and columns[2].startswith("="):
                literal = columns[2]
                if literal not in seen_literals:
                    literal_address = block_addresses[current_block] + location_counter
                    literals_output.write(f"{literal:<10}  {literal_address:04X}\n")
                    seen_literals.add(literal)
    except FileNotFoundError:
        print("Error: Unable to open label or literal output files.")

def pass1():
    
    seen_literals = set()  # Initialize seen_literals once
    with open("in.txt", "r") as input:
        lines = [line.rstrip() for line in input if line.strip()]
        formatted_lines = []
        location_counter = int(lines[0].split()[2], 16)
        current_block = "DEFAULT"  # Set initial block
        literals = []
        loc_width = 6
        rows = []

        for line in lines:
            columns = line.split()

            # Check for "USE" directive to switch blocks
            if len(columns) > 1 and columns[1] == "USE":
                current_block = columns[2] if len(columns) > 2 else "default"
                # Update block address based on current location_counter
                block_addresses[current_block] = location_counter
                print(f"Switching to block {current_block} with address {location_counter:04X}")

            label, opcode, operand = column_breakdown(columns)
            label_width = len(label)
            opcode_width = len(opcode)
            operand_width = len(operand)
            row = {
                "location_counter": f"{location_counter:04X}",
                "label": label,
                "opcode": opcode,
                "operand": operand,
            }
            if operand.startswith('='):
                literals.append(operand)

            rows.append(row)
            if label:
                formatted_line = f"{hexify(location_counter):<{loc_width}}  {label:<{label_width}}  {opcode:<{opcode_width}}  {operand:<{operand_width}}"
            else:
                formatted_line = f"{hexify(location_counter):<{loc_width}} {' ' * (label_width + 2)} {opcode:<{opcode_width}}  {operand:<{operand_width}}"

            symbol_literal_table(location_counter, formatted_line, current_block, seen_literals)

            location_counter, current_block = location_counter_managment(location_counter, opcode, operand, line)
            
            formatted_lines.append(formatted_line)

            location_counter = literal_array_empty(literals, formatted_lines, location_counter, label, opcode, operand)

        with open("out.txt", "w") as outfile:
            outfile.write("\n".join(formatted_lines))

    print(rows)

    print("Pass1 completed.")
    current_size = int('0', 16)
    address = 0
    with open("block_table.txt", 'w') as file:
        file.write(f"{'Block':<15}{'Address':<15}{'Size':<15}\n")
        for block_name, block_info in blocks.items():
            size = int(block_info["size"], 16)
            blocks_line = block_name, hexify((current_size + address)), hexify(size)
            file.write(f"{blocks_line[0]:<15}{blocks_line[1]:<15}{blocks_line[2]:<15}\n")
            current_size += size

    print("Block table written successfully.")




pass1()
print("done")

def pass2():
    base_register = 0

    block_addresses = {}
    label_addresses = {}

    with open("out.txt", "r") as infile, open("object_code.txt", "w") as obj_output:
            for line in infile:
                line = line.strip()
                if line:
                    columns = line.split(maxsplit=3)
                    if columns[1] in opTable or columns[1] in directives or (columns[1].startswith('+') and columns[1][1:] in opTable):
                        
                        label = ""
                        opcode = columns[1]
                        operand = " ".join(columns[2:]) if len(columns) > 1 else ""
            
                    else:
                        label = columns[1]
                        opcode = columns[2]
                        operand = " ".join(columns[3:]) if len(columns) > 2 else ""
                    location_counter = int(columns[0],16) 
                    
                    print(location_counter,label,opcode,operand)
                    obj_code = ""
                    if (columns[1].startswith('+') and columns[1][1:] in opTable):
                        obj_code = handle_format_4(opcode, operand, location_counter,label_addresses)
                    elif opcode in opTable:
                        if opTable[opcode]["format"] in [1,2]:
                            obj_code = handle_format_1_2(opcode, operand,location_counter)
                        elif opTable[opcode]["format"] is 3:
                            obj_code = handle_format3(opcode, operand, location_counter, base_register, label_addresses)
                        
                elif opcode == "BYTE":
                        if operand.startswith("C'"):
                            obj_code = ''.join(f"{ord(c):02X}" for c in operand[2:-1])
                        elif operand.startswith("X'"):
                            obj_code = operand[2:-1]
                elif opcode == "WORD":
                        if operand:
                            obj_code = f"{int(operand):06X}"
                        else:
                            print(f"Error: Missing operand for WORD instruction at {location_counter:04X}")
                elif opcode == "BASE":
                        if operand:
                            base_register = 1000
                        else:
                            print(f"Error: Missing operand for BASE instruction at {location_counter:04X}")
                elif opcode == "USE":
                        current_block = operand if operand else "DEFAULT"
                        continue  # Skip writing object code for USE directive

                    # Write the object code to the output file
                if obj_code:
                        obj_output.write(f"{location_counter:04X} {obj_code}\n")
                        print(f"Wrote object code: {location_counter:04X} {obj_code}")

def handle_format_1_2(opcode, operand, location_counter):
    register_table = {
        "A": 0, "X": 1, "L": 2, "B": 3, "S": 4, "T": 5, "F": 6, "PC": 8, "SW": 9
    }
    obj_code = None  # Initialize obj_code to None
    if opcode in opTable:
        print("bbbbbbbbb")
        if opTable[opcode]["format"] == 1:
            print("aaaaaaaaaaaaaaaaa")
            obj_code = opTable[opcode]["op"]
            return obj_code
        elif opTable[opcode]["format"] == 2:
            if operand:
                r1, r2 = operand.split(",")
                obj_code = f"{opTable[opcode]['op']}{register_table[r1.strip()]:X}{register_table[r2.strip()]:X}"
                return obj_code
            else:
                print(f"Error: Missing operand for format 2 instruction at {location_counter:04X}")
        
def handle_format_4(opcode, operand, location_counter,label_addresses):
    n = i = x = b = p  = 0
    e = 1 
    if opcode[1:] in opTable:
        disp = 0
        if operand.startswith("#"):
                i = 1
                operand = operand[1:]
                print(f"Immediate addressing mode, operand: {operand}")
        elif operand.startswith("@"):
                n = 1
                operand = operand[1:]
                print(f"Indirect addressing mode, operand: {operand}")
        else:
                n = i = 1  # Direct addressing
                print(f"Direct addressing mode, operand: {operand}")
        if "," in operand:
                operand, index = operand.split(",")
                if index.strip() == "X":
                    x = 1
                    print(f"Indexed addressing mode, operand: {operand}, index: {index}")
        if e:
                # Format 4 (20-bit address)
                address = 0
                opcode_r = opTable[opcode[1:]]["op"] 
                opcode_binary = format(int(opcode_r, 16), '08b')[:-2]  
                obj_code =  f"{opcode_binary}{format(n << 5 | i << 4 | x << 3 | b << 2 | p << 1 | e, '06b')}"
                print(obj_code)
                # Make sure the length of the binary string is a multiple of 4
                # Pad with leading zeros if necessary
                obj_code_binary_padded = obj_code.zfill((len(obj_code) + 3) // 4 * 4)

                # Convert the padded binary string to hexadecimal
                obj_code_hex = hex(int(obj_code_binary_padded, 2))[2:].upper()

                # Add leading zeros to ensure it matches the original expected length in hexadecimal
                expected_length = (len(obj_code_binary_padded) + 3) // 4
                obj_code_hex = obj_code_hex.zfill(expected_length)
                print(f"Generated object code: {obj_code_hex}")
                return obj_code_hex

def handle_format3(opcode, operand, location_counter, base_register, label_addresses):
    n = i = x = b = p = e = 0

    if opcode in opTable:
        if opTable[opcode]["format"] in [3]:
            print(f"handle_format3_4 called with opcode: {opcode}, operand: {operand}, location_counter: {location_counter}, base_register: {base_register}")
            
            disp = 0
            if operand.startswith("#"):
                i = 1
                operand = operand[1:]
                print(f"Immediate addressing mode, operand: {operand}")
            elif operand.startswith("@"):
                n = 1
                operand = operand[1:]
                print(f"Indirect addressing mode, operand: {operand}")
            else:
                n = i = 1  # Direct addressing
                print(f"Direct addressing mode, operand: {operand}")
            if "," in operand:
                operand, index = operand.split(",")
                if index.strip() == "X":
                    x = 1
                    print(f"Indexed addressing mode, operand: {operand}, index: {index}")

            # Calculate displacement or address
            
            else:
                # Format 3 (12-bit displacement)
                target_address = 0
                disp = target_address - (location_counter + 3)
                opcode_r = opTable[opcode]["op"] 
                opcode_binary = format(int(opcode_r, 16), '08b')[:-2]  
                obj_code_binary = f"{opcode_binary}{format(n << 5 | i << 4 | x << 3 | b << 2 | p << 1 | e, '06b')}"
                print(obj_code_binary)
                # Make sure the length of the binary string is a multiple of 4
                # Pad with leading zeros if necessary
                obj_code_binary_padded = obj_code_binary.zfill((len(obj_code_binary) + 3) // 4 * 4)

                # Convert the padded binary string to hexadecimal
                obj_code_hex = hex(int(obj_code_binary_padded, 2))[2:].upper()

                # Add leading zeros to ensure it matches the original expected length in hexadecimal
                expected_length = (len(obj_code_binary_padded) + 3) // 4
                obj_code_hex = obj_code_hex.zfill(expected_length)
            print(f"Generated object code: {obj_code_hex}")
            return obj_code_hex

pass2()
