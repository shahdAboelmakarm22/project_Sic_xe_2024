import dis
from tkinter import CURRENT


opTable = {
    "FIX": {"op": "C4", "format": 1},
    "FLOAT": {"op": "C0", "format": 1},
    "HIO": {"op": "F4", "format": 1},
    "NORM": {"op": "C8", "format": 1},
    "SIO": {"op": "F0", "format": 1},
    "TIO": {"op": "F8", "format": 1},
    "ADDR": {"op": "90", "format": 2},
    "COMPR": {"op": "A0", "format": 2},
    "DIVR": {"op": "9C", "format": 2},
    "CLEAR": {"op": "B4", "format": 2},
    "SHIFTL": {"op": "A4", "format": 2},
    "MULR": {"op": "98", "format": 2},
    "RMO": {"op": "AC", "format": 2},
    "SHIFTR": {"op": "A8", "format": 2},
    "SUBR": {"op": "94", "format": 2},
    "SVC": {"op": "B0", "format": 2},
    "TIXR": {"op": "B8", "format": 2},
    "RSUB": {"op": "4C", "format": 3},
    "LDA": {"op": "00", "format": 3},
    "STA": {"op": "0C", "format": 3},
    "LDB": {"op": "68", "format": 3},
    "ADD": {"op": "18", "format": 3},
    "ADDF": {"op": "58", "format": 3},
    "AND": {"op": "40", "format": 3},
    "COMP": {"op": "28", "format": 3},
    "COMPF": {"op": "88", "format": 3},
    "DIV": {"op": "24", "format": 3},
    "DIVF": {"op": "64", "format": 3},
    "J": {"op": "3C", "format": 3},
    "JEQ": {"op": "30", "format": 3},
    "JGT": {"op": "34", "format": 3},
    "JLT": {"op": "38", "format": 3},
    "JSUB": {"op": "48", "format": 3},
    "LDDCH": {"op": "50", "format": 3},
    "LDF": {"op": "70", "format": 3},
    "LDL": {"op": "08", "format": 3},
    "LDS": {"op": "6C", "format": 3},
    "LDT": {"op": "74", "format": 3},
    "LDX": {"op": "04", "format": 3},
    "LPS": {"op": "D0", "format": 3},
    "MUL": {"op": "20", "format": 3},
    "MULF": {"op": "60", "format": 3},
    "OR": {"op": "44", "format": 3},
    "RD": {"op": "D8", "format": 3},
    "SSK": {"op": "EC", "format": 3},
    "STB": {"op": "78", "format": 3},
    "STCH": {"op": "54", "format": 3},
    "STF": {"op": "80", "format": 3},
    "STI": {"op": "D4", "format": 3},
    "STL": {"op": "14", "format": 3},
    "STS": {"op": "7C", "format": 3},
    "STSW": {"op": "E8", "format": 3},
    "STT": {"op": "84", "format": 3},
    "STX": {"op": "10", "format": 3},
    "SUB": {"op": "1C", "format": 3},
    "SUBF": {"op": "5C", "format": 3},
    "TD": {"op": "E0", "format": 3},
    "TIX": {"op": "2C", "format": 3},
    "WD": {"op": "DC", "format": 3},
    "CADD": {"op": "BC", "format": 4},
    "CSUB": {"op": "8C", "format": 4},
    "CLOAD": {"op": "E4", "format": 4},
    "CSTORE": {"op": "FC", "format": 4},
    "CJUMP": {"op": "CC", "format": 4},
    
}
directives = ['START','END','BYTE','RESB','WORD','RESW','BASE','USE','LTORG','EQU']

blocks = {
    "DEFAULT": {"start":0,"size":0},
    "DEFAULTB": {"start":0,"size":0},
    "CDATA": {"start":0,"size":0},
    "CBLKS": {"start":0,"size":0}
}
register_table = {
        "A": 0, "X": 1, "L": 2, "B": 3, "S": 4, "T": 5, "F": 6, "PC": 8, "SW": 9
}
flags = {
    "Z" : "00",
    "N" : "01",
    "C" : "10",
    "V" : "11"
}
current_block = "DEFAULT"

def is_number(variable):
    try:
        float(variable)
        return True
    except (ValueError, TypeError):
        return False
def hexify(x):
    return f"{x:04X}"
def location_counter_managment(location_counter, opcode, operand,line):
    global current_block
    if opcode.startswith("+"):
        location_counter += 4
    elif opcode in opTable:  
        location_counter += opTable[opcode]["format"]
    elif opcode == "RESW": 
        location_counter += 3 * int(operand)
    elif opcode == "RESB":
        location_counter += int(operand)
    elif opcode == "BYTE":
        if operand.startswith("C'"):
            location_counter += len(operand) - 3  # Subtract 3 to account for C' and '
        elif operand.startswith("X'") and operand.endswith("'"):
            location_counter += (len(operand) - 3) // 2  # Each pair of hex digits represents one byte
    elif opcode == "WORD":
        location_counter += 3
    elif opcode == "USE":
        if operand not in blocks and operand != "":
            print(f"Unrecognized block name. in line : {line}")
        elif operand != "":
            if current_block == "DEFAULT":
                blocks["DEFAULT"]["start"] = location_counter
            blocks[current_block]["start"] = location_counter
            blocks[current_block]["size"] = hexify(location_counter)
            current_block = operand
            location_counter = blocks[operand]["start"]
            print(blocks)
        elif operand is "":
            blocks[current_block]["size"] = hexify(location_counter)
            blocks[current_block]["start"] = location_counter
            current_block = "DEFAULT"
            location_counter = blocks["DEFAULT"]["start"]
    elif opcode =="END":
        blocks[current_block]["size"] = hexify(location_counter)
        blocks[current_block]["start"] = location_counter
    return location_counter,current_block
    

def column_breakdown(columns):
    if columns[0] in opTable or columns[0] in directives or (columns[0].startswith('+') and columns[0][1:] in opTable):
        label = ""
        opcode = columns[0]
        operand = " ".join(columns[1:]) if len(columns) > 1 else ""
        return label, opcode, operand  # Add return statement here
    else:
            label = columns[0]
            opcode = columns[1]
            operand = " ".join(columns[2:]) if len(columns) > 2 else ""
            return label, opcode, operand  # Ensure return is present here too
def read_block_addresses(filename):
    block_addresses = {}
    try:
        with open(filename, "r") as file:
            for index, line in enumerate(file):
                if index == 0:
                    continue  # Skip the first line
                line = line.strip()
                if line:
                    parts = line.split()
                    if len(parts) >= 2:
                        block_name = parts[0]
                        block_address = parts[1]
                        block_addresses[block_name] = int(block_address, 16)
                        print(block_addresses)
                    else:
                        print(f"Warning: Invalid line in block_table.txt: {line}")
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    return block_addresses
def literal_array_empty(literals, formatted_lines, location_counter, label, opcode, operand,current_block,block_addresses):
    # Define column widths
    loc_width = 6   # Width for location counter
    label_width = len(label) 
    opcode_width = len(opcode) 
    operand_width = len(operand) 

    formatted_line = ""  # Initialize formatted_line variable
    literals_array_flag = 0
    if opcode == "LTORG" or (literals and opcode == "END"):
        seen_literals = set()
        for literal in literals:
            if literal not in seen_literals:
                formatted_lines.append(f"{hexify(location_counter):<{loc_width}}  *{' ' * (label_width)} {literal:<{operand_width}}")
                with open("Literal_table.txt", "a") as file:
                    literal_address = block_addresses[current_block] + location_counter
                    file.write(f"{literal:<10}  {literal_address:04X}\n")
            seen_literals.add(literal)
            if literal.startswith("=C"):
                location_counter += len(literal) - 4
            elif literal.startswith("=X"):
                location_counter += (len(literal) - 3) // 2
        literals.clear()
        
    return location_counter


def symbol_table(location_counter, current_line, current_block, seen_literals, block_addresses):
    try:
        with open("Symbol_table.txt", "a") as labels_output:
            columns = current_line.strip().split(maxsplit=3)

            if len(columns) > 0:
                # Check if the first column can be converted to an integer (hexadecimal)
                try:
                    location_counter = int(columns[0], 16)
                except ValueError:
                    # Skip this line if the first column is not a valid hex number
                    pass

            if len(columns) > 1 and columns[1]:
                label = columns[1]

                if (label not in opTable and label not in directives
                    and not label.startswith("+") and not label.startswith("=")):
                    label_address = block_addresses[current_block] + location_counter
                    labels_output.write(f"{label:<10}  {label_address:04X}\n")
                

    except FileNotFoundError:
        print("Error: Unable to open label or literal output files.")

def pass1():
    with open("Symbol_table.txt", "w") as labels_output, open("Literal_table.txt", "w") as literals_output:
        labels_output.write("")
        literals_output.write("")
    seen_literals = set()  # Initialize seen_literals once
    with open("in.txt", "r") as input:
        lines = [line.rstrip() for line in input if line.strip()]
        formatted_lines = []
        location_counter = int(lines[0].split()[2], 16)
        current_block = "DEFAULT"  # Set initial block
        literals = []
        loc_width = 6
        rows = []
        block_addresses = read_block_addresses("block_table.txt")
        print(block_addresses)
        for line in lines:
            columns = line.split()

            label, opcode, operand = column_breakdown(columns)
            label_width = len(label)
            opcode_width = len(opcode)
            operand_width = len(operand)
            row = {
                "location_counter": f"{location_counter:04X}",
                "label": label,
                "opcode": opcode,
                "operand": operand,
            }
            if operand.startswith('='):
                literals.append(operand)

            rows.append(row)
            if label:
                formatted_line = f"{hexify(location_counter):<{loc_width}}  {label:<{label_width}}  {opcode:<{opcode_width}}  {operand:<{operand_width}}"
            else:
                formatted_line = f"{hexify(location_counter):<{loc_width}} {' ' * (label_width + 2)} {opcode:<{opcode_width}}  {operand:<{operand_width}}"

            location_counter, current_block = location_counter_managment(location_counter, opcode, operand, line)
            
            formatted_lines.append(formatted_line)

            location_counter= literal_array_empty(literals, formatted_lines, location_counter, label, opcode, operand,current_block,block_addresses)
            symbol_table(location_counter, formatted_line, current_block, seen_literals, block_addresses)
        with open("out.txt", "w") as outfile:
            outfile.write("\n".join(formatted_lines))

    print(rows)

    print("Pass1 completed.")
    current_size = int('0', 16)
    address = 0
    with open("block_table.txt", 'w') as file:
        file.write(f"{'Block':<15}{'Address':<15}{'Size':<15}\n")
        for block_name, block_info in blocks.items():
            size = int(block_info["size"], 16)
            blocks_line = block_name, hexify((current_size + address)), hexify(size)
            file.write(f"{blocks_line[0]:<15}{blocks_line[1]:<15}{blocks_line[2]:<15}\n")
            current_size += size

    print("Block table written successfully.")




def pass2():
    base_register = 0

    block_addresses = {}
    label_addresses = {}

    with open("out.txt", "r") as infile, open("object_code.txt", "w") as obj_output:
            for line in infile:
                line = line.strip()
                if line:
                    columns = line.split(maxsplit=3)
                    if columns[1] in opTable or columns[1] in directives or (columns[1].startswith('+') and columns[1][1:] in opTable):
                        label = ""
                        opcode = columns[1]
                        operand = " ".join(columns[2:]) if len(columns) > 1 else ""
            
                    else:
                        label = columns[1]
                        opcode = columns[2]
                        operand = " ".join(columns[3:]) if len(columns) > 2 else ""
                    location_counter = int(columns[0],16) 
                    
                    print(location_counter,label,opcode,operand)
                    obj_code = ""
                    if (columns[1].startswith('+') and columns[1][1:] in opTable):
                        obj_code = handle_format_4(opcode, operand, location_counter,label_addresses)
                    elif opcode in opTable:
                        if opTable[opcode]["format"] in [1,2]:
                            obj_code = handle_format_1_2(opcode, operand,location_counter)
                        elif opTable[opcode]["format"] is 3:
                            obj_code = handle_format3(opcode, operand, location_counter, base_register, label_addresses)
                        elif opTable[opcode]["format"] is 4:
                            obj_code = handle_format_4f(opcode, operand, location_counter,label_addresses)
                    elif opcode == "BYTE":
                            if operand.startswith("C'"):
                                obj_code = ''.join(f"{ord(c):02X}" for c in operand[2:-1])
                            elif operand.startswith("X'"):
                                obj_code = operand[2:-1]
                    elif opcode == "WORD":
                            if operand:
                                obj_code = f"{int(operand):06X}"
                            else:
                                print(f"Error: Missing operand for WORD instruction at {location_counter:04X}")
                    elif opcode == "BASE":
                            if operand:
                                base_register = int(get_symbol_or_literal_address(operand))
                            else:
                                print(f"Error: Missing operand for BASE instruction at {location_counter:04X}")
                    elif '=' in opcode:
                        obj_code = handle_literals(opcode)
                    elif opcode == "USE":
                            obj_code = '-'  
                    
                if obj_code:
                        obj_output.write(f"{location_counter:04X} {opcode:<7} {operand:<20} {obj_code:<8}\n")
                        print(f"Wrote object code: {location_counter:04X} {obj_code}")
def handle_literals(opcode):
    ascii_values = []  # Initialize the variable to avoid the UnboundLocalError
    
    if opcode.startswith("=C"):
        opcode = opcode[3:-1]
        ascii_values = [format(ord(char), '02X') for char in opcode]
        return ''.join(ascii_values)
    elif opcode.startswith("=X"):
        opcode = opcode[3:-1]
        return opcode
def handle_format_1_2(opcode, operand, location_counter):
    obj_code = None  # Initialize obj_code to None
    print("bbbbbbbbb")
    if opTable[opcode]["format"] == 1:
        print("aaaaaaaaaaaaaaaaa")
        obj_code = opTable[opcode]["op"]
        return obj_code
    elif opTable[opcode]["format"] == 2:
            if operand:
                r1, r2 = operand.split(",")
                obj_code = f"{opTable[opcode]['op']}{register_table[r1.strip()]:X}{register_table[r2.strip()]:X}"
                return obj_code
            else:
                print(f"Error: Missing operand for format 2 instruction at {location_counter:04X}")

def handle_format3(opcode, operand, location_counter, base_register, label_addresses):
    n = i = x = b = p = e = 0
    print(f"handle_format3 called with opcode: {opcode}, operand: {operand}, location_counter: {location_counter}, base_register: {base_register}")     
    disp = 0
    if operand.startswith("#"):
        i = 1
        operand = operand[1:]
        print(f"Immediate addressing mode, operand: {operand}")
    elif operand.startswith("@"):
        n = 1
        operand = operand[1:]
        print(f"Indirect addressing mode, operand: {operand}")
    else:
        n = i = 1  
        print(f"Direct addressing mode, operand: {operand}")
    if "," in operand:
        operand, index = operand.split(",")
        if index.strip() == "X":
            x = 1
            print(f"Indexed addressing mode, operand: {operand}, index: {index}")
    else:
        target_address = 0
        if i and not n:
            if is_number(operand):
                target_address = int(operand)
                disp = target_address 
            else:
                target_address = get_symbol_or_literal_address(operand)
                disp = target_address
        elif n and not i:
            if is_number(operand):
                target_address = int(operand)
                predisp = target_address - (location_counter + 6)
                print(f"Predisp: {predisp}")
                if -2048 <= predisp <= 2047:
                    disp = predisp
                    p = 1
                elif 0 <= target_address - base_register <= 4095:
                    disp = target_address - base_register
                    b = 1
                else:
                    raise ValueError("Displacement out of range for both PC and Base-relative addressing.")
            else:
                target_address = get_symbol_or_literal_address(operand)
                predisp = target_address - (location_counter + 6)
                print(f"Predisp: {predisp}")
                if -2048 <= predisp <= 2047:
                    disp = predisp
                    p = 1
                elif 0 <= target_address - base_register <= 4095:
                    disp = target_address - base_register
                    b = 1
                else:
                    raise ValueError("Displacement out of range for both PC and Base-relative addressing.")
        elif n and i:
            target_address = get_symbol_or_literal_address(operand)
            predisp = target_address - (location_counter + 6)
            print(f"Predisp: {predisp}")
            if -2048 <= predisp <= 2047:
                disp = predisp
                p = 1
            elif 0 <= target_address - base_register <= 4095:
                disp = target_address - base_register
                b = 1
            else:
                raise ValueError("Displacement out of range for both PC and Base-relative addressing.")

    opcode_r = opTable[opcode]["op"]
    opcode_binary = format(int(opcode_r, 16), '08b')[:-2]  
    obj_code_binary = f"{opcode_binary}{format(n << 5 | i << 4 | x << 3 | b << 2 | p << 1 | e, '06b')}"
    print(f"Opcode binary: {obj_code_binary}")
    obj_code_binary_padded = obj_code_binary.zfill((len(obj_code_binary) + 3) // 4 * 4)
    obj_code_hex = hex(int(obj_code_binary_padded, 2))[2:].upper()

    # Add leading zeros to ensure it matches the original expected length in hexadecimal
    expected_length = (len(obj_code_binary_padded) + 3) // 4
    obj_code_hex = obj_code_hex.zfill(expected_length)
    
    # Format disp as a 3-digit hexadecimal value
    disp_hex = f"{disp & 0xFFF:03X}"  # Ensure only the lower 12 bits are used, and format as 3-digit hex
    obj_code_hex = f"{obj_code_hex}{disp_hex}"
    
    print(f"Generated object code: {obj_code_hex}")
    return obj_code_hex



def get_symbol_or_literal_address(label):
    """
    Reads the symbol and literal tables and retrieves the address for the given label.
    """
    try:
        # Check Symbol_table.txt first
        try:
            with open("Symbol_table.txt", "r") as file:
                for line in file:
                    parts = line.split()
                    if len(parts) == 2:
                        symbol, address = parts
                        if symbol == label:
                            return int(address, 16)  # Assume address is in hexadecimal
        except FileNotFoundError:
            print("Symbol_table.txt not found. Continuing to Literal_table.txt.")

        # Check Literal_table.txt next
        try:
            with open("Literal_table.txt", "r") as file:
                for line in file:
                    parts = line.split()
                    if len(parts) == 2:
                        symbol, address = parts
                        if symbol == label:
                            return int(address, 16)  # Assume address is in hexadecimal
        except FileNotFoundError:
            print("Literal_table.txt not found.")

        # If not found in either file, raise an error
        raise ValueError(f"Label {label} not found in Symbol_table.txt or Literal_table.txt")
    except Exception as e:
        raise RuntimeError(f"Error reading symbol or literal tables: {e}")
    
def handle_format_4(opcode, operand, location_counter, label_addresses):
    n = i = x = b = p = 0
    e = 1  # Format 4 uses extended addressing
    disp = 0
    print(f"handle_format_4 called with opcode: {opcode}, operand: {operand}, location_counter: {location_counter}")

    # Determine addressing mode
    if operand.startswith("#"):
        i = 1
        operand = operand[1:]
        print(f"Immediate addressing mode, operand: {operand}")
    elif operand.startswith("@"):
        n = 1
        operand = operand[1:]
        print(f"Indirect addressing mode, operand: {operand}")
    else:
        n = i = 1
        print(f"Direct addressing mode, operand: {operand}")

    # Handle indexed addressing
    if "," in operand:
        operand, index = operand.split(",")
        if index.strip() == "X":
            x = 1
            print(f"Indexed addressing mode, operand: {operand}, index: {index}")

    # Calculate the target address
    target_address = 0
    if is_number(operand):
        target_address = int(operand)
    else:
        target_address = get_symbol_or_literal_address(operand)

    disp = target_address

    # Generate opcode
    opcode_r = opTable[opcode[1:]]["op"]
    opcode_binary = format(int(opcode_r, 16), '08b')[:-2]  # Convert to binary, drop last 2 bits
    obj_code_binary = f"{opcode_binary}{format(n << 5 | i << 4 | x << 3 | b << 2 | p << 1 | e, '06b')}"
    print(f"Opcode binary: {obj_code_binary}")

    # Pad binary string to a multiple of 4
    obj_code_binary_padded = obj_code_binary.zfill((len(obj_code_binary) + 3) // 4 * 4)

    # Convert to hexadecimal and pad to the correct length
    obj_code_hex = hex(int(obj_code_binary_padded, 2))[2:].upper()
    expected_length = (len(obj_code_binary_padded) + 3) // 4
    obj_code_hex = obj_code_hex.zfill(expected_length)

    # Append 5-digit hexadecimal representation of disp
    disp_hex = f"{disp & 0xFFFFF:05X}"  # Ensure disp is within 20 bits (format 4 uses 20-bit addresses)
    obj_code_hex = f"{obj_code_hex}{disp_hex}"

    print(f"Generated object code: {obj_code_hex}")
    return obj_code_hex

def handle_format_4f(opcode, operand, location_counter, label_addresses):
    if opcode in opTable:
        opcode_r = opTable[opcode]["op"] 
        opcode_binary = format(int(opcode_r, 16), '08b')[:-2]  
        flag = 0
        r1 = operand.split(",")
        if opcode == "CJUMP":
            r = 'A'
            flag = int(flags[r1[1]], 2)
            target_address = get_symbol_or_literal_address(r1[0])
        else:
            r = r1[0].strip()
            flag = int(flags[r1[2]], 2)
            target_address = get_symbol_or_literal_address(r1[1])
        
        obj_code = f"{opcode_binary}{register_table[r]:04b}{flag:02b}"
        print(obj_code)
        
        obj_code_binary_padded = obj_code.zfill((len(obj_code) + 3) // 4 * 4)
        obj_code_hex = hex(int(obj_code_binary_padded, 2))[2:].upper()
        expected_length = (len(obj_code_binary_padded) + 3) // 4
        obj_code_hex = obj_code_hex.zfill(expected_length)
        
        disp = target_address
        disp_hex = f"{disp:05X}"  # Format displacement with zero-padding to 5 hexadecimal digits
        
        obj_code_hex = f"{obj_code_hex}{disp_hex}"
        print(f"Generated object code: {obj_code_hex}")
        return obj_code_hex


def generate_htme_record():
    with open("out.txt", "r") as out_file:
        first_label = out_file.readline().strip().split()[1][:6].ljust(6)
    
    with open("object_code.txt", "r") as obj_file, open("htme_record.txt", "w") as htme_file, open("block_table.txt", "r") as block_file:
        htme_file.write("H^")
        program_name = first_label
        start_address = "000000"
        
        # Read the CBLKS address and size from block_table.txt
        cblks_address, cblks_size = None, None
        for line in block_file:
            if "CBLKS" in line:
                columns = line.split()
                cblks_address = int(columns[1], 16)
                cblks_size = int(columns[2], 16)
                break
        
        program_length = hex(cblks_address + cblks_size)[2:].upper().zfill(6) if cblks_address and cblks_size else "000000"
        htme_file.write(f"{program_name:<6}^{start_address:>6}^{program_length:>6}\n")
        block_addresses = read_block_addresses("block_table.txt")
        text_records, modification_records = [], []
        current_record, current_address, instruction_count = "", None, 0
        current_block = "DEFAULT"
        for line in obj_file:
            columns = line.split()
            if columns[1] == "USE":
                if columns[2] == "DEFAULTB":
                    current_block = "DEFAULTB"
                elif columns[2] == "CBLKS":
                    current_block = "CBLKS"
                elif columns[2] == "CDATA":
                    current_block = "CDATA"
                else:
                    current_block = "DEFAULT"
            address = columns[0] 
            obj_code = columns[-1]
            if current_address is None:
                current_address = hex(block_addresses[current_block] + int(address,16))[2:].upper().zfill(6)
            if obj_code == "-":
                obj_code = ""
            if len(current_record) + len(obj_code) > 60 or instruction_count >= 10 or (columns[1] in directives and columns[1] not in ["WORD", "BYTE"]):
                if current_record:
                    record_length = hex(len(current_record)//2 )[2:].upper().zfill(2)
                    text_records.append(f"T^{current_address:>6}^{record_length:>2}^{current_record}")
                current_record, current_address, instruction_count = "", None, 0
            
            current_record = f"{current_record}{obj_code}" if current_record else obj_code
            instruction_count += 1
            
            # Add modification record for Format 4 instructions
            if columns[1].startswith('+') or (columns[1] in opTable and opTable[columns[1]]["format"] == 4):
                
                mod_address = hex(block_addresses[current_block] +int(address, 16) + 1)[2:].upper().zfill(6)
                modification_records.append(f"M^{mod_address:>6}^05")
        
        if current_record:
            record_length = hex(len(current_record) // 2)[2:].upper().zfill(2)
            text_records.append(f"T^{current_address:>6}^{record_length:>2}^{current_record}")
        
        for record in text_records:
            htme_file.write(record + "\n")
        
        for record in modification_records:
            htme_file.write(record + "\n")
        
        htme_file.write("E^" + start_address + "\n")

pass1()
pass2()
generate_htme_record()
print("done")